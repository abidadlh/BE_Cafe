const express = require(`express`)
const { Model } = require("sequelize")
const app = express()

app.use(express.json()) // membaca data dalam format json

// call menu controller
let menuController = require("../controllers/menu.controller")

// call testMiddleware
let uploadImage = require("../middlewares/uploadImage")
let authorization = require("../middlewares/authorization")

// end-point get data menu
app.get("/", menuController.getDataMenu)
app.get("/makanan", menuController.getMakanan)
app.get("/minuman", menuController.getMinuman)

app.post("/find", menuController.findMenu)

// end-point add data menu
app.post("/", [
    uploadImage.upload.single(`gambar`),
    menuController.addDataMenu
])

// end-point edit data menu
app.put("/:id_menu", [
    uploadImage.upload.single(`gambar`),
    authorization.authorization,
    menuController.editDataMenu
])
// end-point delete data menu
app.delete("/:id_menu", [authorization.authorization], menuController.deleteDataMobil)

module.exports = app