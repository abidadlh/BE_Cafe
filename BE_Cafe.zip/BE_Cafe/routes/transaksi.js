const express = require(`express`)
const { Model } = require("sequelize")
const app = express()

app.use(express.json())

let transaksiController = require("../controllers/transaksi.controller")
let authorization = require("../middlewares/authorization")

//end-point get data transaksi
app.get("/",  transaksiController.getTransaksi)

//end-point add data transaksi
app.post("/",  transaksiController.addTransaksi)

//end-point filter
app.post("/filter", transaksiController.filter)

//end-point handle (search transaksi)
app.post("/find",  transaksiController.findTransaksi)

//end-point edit data transaksi
app.put("/:id_transaksi", transaksiController.editTransaksi)

//end-point edit status data transaksi
app.put("/status/:id_transaksi", transaksiController.editStatus)

//end-point hapus data transaksi
app.delete("/:id_transaksi", transaksiController.deleteTransaksi)

module.exports = app