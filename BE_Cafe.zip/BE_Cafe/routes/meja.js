const express = require(`express`)
const app = express()
const authorization = require("../middlewares/authorization")

app.use(express.json()) // membaca data dalam format json

let mejaController = require("../controllers/meja.controller")

// end-point get data siswa
app.get("/", mejaController.getDataMeja)

// end-point add data siswa
app.post("/", mejaController.addDataMeja)

// end-point edit data siswa
app.put("/:id_meja", mejaController.editDataMeja)

// end-point delete data siswa
app.delete("/:id_meja", mejaController.deleteDataMeja)

app.post("/find", [ mejaController.findMeja])  

module.exports = app