const express = require(`express`)
const app = express()
const { body } = require (`express-validator`)

app.use(express.json()) // membaca data dalam format json

// call menu controller
const userController = require("../controllers/user.controller")

/** load authorization function from controllers */
const { authorize } = require(`../controllers/auth.controller`)

// call middleware
const userValidator = require("../middlewares/userValidator")
const authorization = require("../middlewares/authorization")

// end-point get data user
app.get("/", [authorize], userController.getDataUser)

// end-point add data user
app.post("/", [authorize],[ userValidator.validate], userController.addDataUser)

// end-point edit data user
app.put("/:id_user", [authorize], userController.editDataUser)

// end-point delete data user
app.delete("/:id_user", [authorize], userController.deleteDataUser)

app.post("/auth", [authorize], userController.authentication)

app.post("/find", [authorize],[ userController.findUser])   
module.exports = app