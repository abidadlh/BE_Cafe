const multer = require("multer")
const path = require("path")
const fs = require("fs")
const { request } = require("http")

const storage = multer.diskStorage({
    destination: (request, file, callback) => {
        callback(null, "./image")
        // ini config utk menentukan folder penyimpanan yg diupload
    },
    filename: (request, file, callback) => {
        callback(null, `image-${Date.now()}${path.extname(file.originalname)}`) 
        // ini config utk menentukan file penyimpanan yg diupload
    }
})

exports.upload = multer({storage: storage})