'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class meja extends Model {
   
    static associate(models) {
      // define association here
    }
  }
  meja.init({
    id_meja:{
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      columnName: 'id_meja'
    },
    nomor_meja: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'meja',
    tableName: 'mejas'
  });
  return meja;
};