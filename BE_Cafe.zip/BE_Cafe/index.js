const express = require(`express`)//load library express
const app = express()//create object that instance of express
const PORT = 8000 //define port server
const cors = require('cors')//load library cors
app.use(cors())//open cors policy
app.use(express.static(__dirname))//route to access uploaded file

//prefix adalah bagian awal dari URL yang akan digunakan untuk mengakses rute tertentu. 
//route adalah file JavaScript yang berisi logika untuk menangani permintaan HTTP pada rute tersebut.
let routes = [
    {prefix: `/user`, route: require(`./routes/user`)}, 
    {prefix: `/menu`, route: require(`./routes/menu`)},
    {prefix: `/meja`, route: require(`./routes/meja`)},
    {prefix: `/transaksi`, route: require(`./routes/transaksi`)},
    {prefix: `/auth`, route: require(`./routes/auth`)}
]

for (let i = 0; i < routes.length; i++) {
    app.use(routes[i].prefix, routes[i].route)
}

app.listen(PORT, () => {
    console.log(`Server run on port ${PORT}`)
})

